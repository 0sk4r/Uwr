CREATE FUNCTION xpath_exists(text, xml)
  RETURNS boolean
IMMUTABLE
STRICT
PARALLEL SAFE
COST 1
LANGUAGE SQL
AS $$
select pg_catalog.xpath_exists($1, $2, '{}'::pg_catalog.text[])
$$;

