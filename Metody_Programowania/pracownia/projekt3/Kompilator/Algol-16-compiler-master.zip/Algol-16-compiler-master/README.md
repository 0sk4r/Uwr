# Algol-16-compiler for Sextium III © Processor

Language version: simple - 22 pts

# How to use?

Use instr_list_to_file( input_file_with_algol16_code, machine_code_output_file ) predicate to generate Sextium III machine code.</br>
Then use script ./compile_words_and_run.sh machine_code_output_file to generate binary file and execute program.

For sure works with SWI-Prolog 6.6.4. May be some problems with version 7.x.x due to different string handling.

