# Compiler-ALGOL16
[Prolog] Compiler ALGOL16

Kompilator okrojonego ALGOL16 (zmodyfikowany ALGOL60) do kodu maszynowego proesora Sextium III.
