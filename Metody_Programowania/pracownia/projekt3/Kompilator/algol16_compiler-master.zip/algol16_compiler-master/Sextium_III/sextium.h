/*
 * sextium.h - specification of the Sextium® III emulator
 */

enum syscall_code {
   HALT_SYS,   // 0
   READ_SYS,   // 1
   WRITE_SYS   // 2
};

// twi 2016/04/05 vim:fenc=utf8:ts=3:cc=73,74,75,76,77,78,79,80:
