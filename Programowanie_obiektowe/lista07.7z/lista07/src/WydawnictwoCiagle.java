public class WydawnictwoCiagle extends Ksiazka
{
    public WydawnictwoCiagle(String T, String a, int w) { super(T, a, w); }
    public WydawnictwoCiagle() { super(); }
}