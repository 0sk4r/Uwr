public class Czasopismo extends Ksiazka
{
    public Czasopismo(String T, String a, int w) { super(T, a, w); }
    public Czasopismo() { super(); }
}